var APP_DATA = {
  "scenes": [
    {
      "id": "0-new-hotness",
      "name": "New hotness",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": -0.016746229496751752,
        "pitch": 0.27663937829882457,
        "fov": 1.574382220999014
      },
      "linkHotspots": [
        {
          "yaw": -0.9673998106228012,
          "pitch": 0.1523125617397465,
          "rotation": 4.71238898038469,
          "target": "1-unit-1-the-og"
        },
        {
          "yaw": -1.3435835218256784,
          "pitch": 0.0809446881365794,
          "rotation": 3.9269908169872414,
          "target": "2-unit-1"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-unit-1-the-og",
      "name": "Unit 1, the OG",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -1.0202644557908584,
          "pitch": 0.25082746622693186,
          "rotation": 10.210176124166829,
          "target": "2-unit-1"
        },
        {
          "yaw": 1.1989780955235503,
          "pitch": 0.10290678726520852,
          "rotation": 2.356194490192345,
          "target": "0-new-hotness"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-unit-1",
      "name": "Unit 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        }
      ],
      "faceSize": 1024,
      "initialViewParameters": {
        "yaw": 0,
        "pitch": 0,
        "fov": 1.574382220999014
      },
      "linkHotspots": [
        {
          "yaw": 0.4210389467391913,
          "pitch": 0.6590926245592517,
          "rotation": 1.5707963267948966,
          "target": "1-unit-1-the-og"
        },
        {
          "yaw": 1.1357855442219886,
          "pitch": 0.11984791295318331,
          "rotation": 2.356194490192345,
          "target": "0-new-hotness"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Control room",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
